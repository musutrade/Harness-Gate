import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd()
out = root / 'target/quality/gh-198'
env = dict(os.environ, CARGO_TARGET_DIR=str(root / 'target'))
commands = [
    'cargo nextest run --manifest-path tools/harness-gate/Cargo.toml --locked',
    'cargo fmt --manifest-path tools/harness-gate/Cargo.toml -- --check',
    'cargo clippy --manifest-path tools/harness-gate/Cargo.toml --all-targets -- -D warnings',
    'python3 -m unittest discover -s tools/quality/tests -v',
    'python3 tools/quality/docs_consistency.py --output target/quality/docs-consistency.json',
    'openspec validate integrate-generic-quality-into-project-workflow --strict',
    'git diff --check',
]
records = []
for index, command in enumerate(commands):
    log = out / f'check-{index + 1}.log'
    start = time.monotonic()
    with log.open('w') as stream:
        result = subprocess.run(command, shell=True, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record = dict(command=command, exit_code=result.returncode,
                  seconds=round(time.monotonic() - start, 3), log=log.name,
                  sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    records.append(record)
    (out / 'validation.json').write_text(json.dumps(dict(environment={'CARGO_TARGET_DIR': '$PWD/target'}, checks=records), indent=2) + '\n')
    print(json.dumps(record), flush=True)
