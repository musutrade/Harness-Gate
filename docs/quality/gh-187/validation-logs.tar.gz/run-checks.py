import datetime,json,os,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'target/quality/gh-187'
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),HARNESS_GATE_CI_ACCEPTANCE=str(out/'final-workflow-acceptance'))
checks=[('nextest', 'cargo nextest run --manifest-path tools/harness-gate/Cargo.toml --locked'), ('fmt', 'cargo fmt --manifest-path tools/harness-gate/Cargo.toml -- --check'), ('clippy', 'cargo clippy --manifest-path tools/harness-gate/Cargo.toml --all-targets -- -D warnings'), ('quality-python', 'python3 -m unittest discover -s tools/quality/tests -v'), ('release-python', 'python3 -m unittest discover -s tools/release/tests -v'), ('py-compile', 'python3 -m py_compile tools/quality/*.py tools/quality/tests/*.py'), ('build', 'cargo build --manifest-path tools/harness-gate/Cargo.toml --locked --release'), ('contracts', 'python3 tools/quality/contracts.py --output target/quality/gh-187/contracts.json --structured'), ('security-audit', 'cargo audit --deny warnings --file tools/harness-gate/Cargo.lock')]
results=[]
for name,command in checks:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,shell=True,env=env,stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,command=command,started_at=start,duration_seconds=round(time.monotonic()-t,3),exit_code=result.returncode,log=name+'.log')
 results.append(record); (out/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name, result.returncode, record['duration_seconds'], flush=True)
