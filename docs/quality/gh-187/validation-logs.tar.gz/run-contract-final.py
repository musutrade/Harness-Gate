import datetime,json,os,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'target/quality/gh-187'
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),HARNESS_GATE_CI_ACCEPTANCE=str(out/'final-workflow-acceptance'))
checks=[('contracts-accept', 'python3 tools/quality/contracts.py --output target/quality/gh-187/contracts-accepted.json --accept'), ('contracts-linux-final', 'python3 tools/quality/contracts.py --output target/quality/gh-187/contracts-linux-final.json')]
results=[]
for name,command in checks:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,shell=True,env=env,stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,command=command,started_at=start,duration_seconds=round(time.monotonic()-t,3),exit_code=result.returncode,log=name+'.log')
 results.append(record); (out/'contract-final-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name, result.returncode, record['duration_seconds'], flush=True)
