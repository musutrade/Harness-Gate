import datetime,json,os,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'target/quality/gh-187'
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),HARNESS_GATE_CI_ACCEPTANCE=str(out/'final-workflow-acceptance'))
checks=[('docs-consistency-final', 'python3 tools/quality/docs_consistency.py --output target/quality/docs-consistency.json'), ('openspec-final', 'openspec validate integrate-generic-quality-into-project-workflow --strict'), ('local-receipt-final', 'python3 tools/quality/ci_acceptance.py --directory target/quality/gh-187/final-workflow-acceptance'), ('hosted-receipt-final', 'GITHUB_SHA=ffe3bc0e5f7dea4f864ceab653b26debb78d235d GITHUB_RUN_ID=34419625673 GITHUB_RUN_ATTEMPT=1 RUNNER_OS=Linux RUNNER_ARCH=X64 python3 tools/quality/ci_acceptance.py --directory target/quality/gh-187/hosted-prerequisite'), ('diff-check-final', 'git diff --check')]
results=[]
for name,command in checks:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,shell=True,env=env,stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,command=command,started_at=start,duration_seconds=round(time.monotonic()-t,3),exit_code=result.returncode,log=name+'.log')
 results.append(record); (out/'final-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name, result.returncode, record['duration_seconds'], flush=True)
