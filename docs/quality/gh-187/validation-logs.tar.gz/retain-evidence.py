import datetime,gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path.cwd(); source=root/'target/quality/gh-187'; out=root/'docs/quality/gh-187'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for name in ['checks.json','additional-checks.json','audit-checks.json','audit-final-checks.json','contract-final-checks.json','final-checks.json']:
 p=source/name
 if p.exists():
  for c in json.loads(p.read_text()):
   c['log_sha256']=sha(source/c['log']);c['environment']={'CARGO_TARGET_DIR':'$PWD/target','HARNESS_GATE_CI_ACCEPTANCE':'$PWD/target/quality/gh-187/final-workflow-acceptance'}
   checks.append(c)
files=sorted(set(source.glob('*.log'))|set(source.glob('*-help.txt'))|set(source.glob('run-*.py'))|{source/'retain-evidence.py'})
files += [p for p in [root/'target/quality/docs-consistency.json',source/'contracts-linux-final.json',source/'contracts.json'] if p.exists()]
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for p in files:
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
(out/'validation-logs.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
artifacts={p.name:{'sha256':sha(p),'size_bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.name not in ['validation.md','validation.json']}
manifest={'schema':'quality-implementation-validation/v1','issue':187,'baseline_sha':'fd0d040fad1f051c64adb18b9a644fbe3c3dd24a','scope':'Documentation, CLI help and reviewed help snapshot only; final pushed identity is in the controller handoff and PR.','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'artifacts':artifacts,'archive_members':{p.name:sha(p) for p in files},'notes':['Initial Python suite: 346 tests, one documentation consistency error while closure links were being edited. Focused five-test recheck and final full 346-test suite passed after link correction.','Linux textual snapshot initially differed only in the intended root help stdout. Reviewed update accepted; fresh normal contract comparison passed. Structured contracts passed.','Initial cargo audit failed to lock read-only /home/gem/.cargo/advisory-db..lock. Relocating only the advisory DB returned zero with a crates.io index lock warning. Final audit relocates both DB and CARGO_HOME and passes without that warning. No advisory policy was relaxed.','Cargo target is inside the current workspace. Root project-local flow.toml is absent; config check and verify --profile ci --all are not applicable. Temporary configured fixtures are tested.','Current-head hosted native jobs, production quality collection and Required Quality Aggregate are pending; prerequisite run 34419625673 attempt 1 is historical success only.','Retained receipts include synthetic public fixture trust material, not application credentials. Receipt identity is empty for local execution and pinned to the tested merge for hosted execution.','Read-only current workspace Git index blocked normal staging. Delivery uses a metadata copy beneath this same workspace target directory and preserves the prepared branch/base; no other workspace is accessed.'],'not_applicable':[{'command':'harness-gate config check','reason':'No project-local .harness-gate/flow.toml.'},{'command':'harness-gate verify --profile ci --all','reason':'No project-local .harness-gate/flow.toml or declared ci profile.'}],'hosted_prerequisite':{'run_id':34419625673,'attempt':1,'pr_number':196,'head_sha':'024f775904eb6bd50639092d3779d9e2f8dad035','tested_merge_sha':'ffe3bc0e5f7dea4f864ceab653b26debb78d235d','required_aggregate':'success','receipt_validator':'Exact hosted environment and content hashes checked by ci_acceptance.py; see command log.'}}
(out/'validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
