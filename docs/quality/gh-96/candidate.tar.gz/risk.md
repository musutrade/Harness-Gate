# Candidate function risk

Base: `c0e612351c2efd515fde96bcefad80c1365534a2`

Head: `41e23761e0caa06cab1f6d5ebca1a79648fbb301`

Identities: 212; failures: 0.

Scope: six GH-94 files. Raw counters, exact rational CRAP and historical debt are retained in head-risk.json. Branch coverage is unsupported. This candidate is not an accepted baseline.
