# Coverage Baseline

Commit: `41e23761e0caa06cab1f6d5ebca1a79648fbb301`
Threshold: 80.0%

| Module | Covered | Executable | Coverage | Status |
| --- | ---: | ---: | ---: | --- |
| `config` | 2405 | 2758 | 87.20% | pass |
| `verify` | 4282 | 4963 | 86.28% | pass |
| `process` | 1652 | 1930 | 85.60% | pass |
| `audit` | 886 | 1075 | 82.42% | pass |
| `scope` | 97 | 113 | 85.84% | pass |
| `secrets` | 427 | 470 | 90.85% | pass |
| `service` | 1702 | 1997 | 85.23% | informational |

Blocking core aggregate: **86.21%**

Service adapter coverage is informational and requires service-contract evidence.
