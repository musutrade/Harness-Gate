# Quality Baseline

Serial verification median: **0.972s**

Parallel verification median: **0.644s**

Comparison speedup: **1.509x**

Comparison delta: **-33.73%**

Scope matcher cached median: **8853.5us**; uncached: **16078.2us** (1.82x speedup)

Series key: `x86_64-unknown-linux-gnu:rustc 1.97.1 (8bab26f4f 2026-07-14):1:1:cold-and-warm`

Test warm median: **12.131s** (cold: 11.932s)

Release-small binary: **8711168 bytes**
SHA-256: `3efaf9115eebf7a75e2f0f8ffeb6a44a2ffeed6b065fa9d96b8bc6137b0f0c5b`
