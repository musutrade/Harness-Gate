=== Verification report ===
Timestamp: 2026-09-07T10:38:23.247093249+00:00
Profile: full
Components: project

- PASS: secret scan (61 ms)
- PASS: architecture audit (20 ms) - 0 violation(s), 0 blocker(s), 0 error(s), 0 warning(s)
- PASS: benchmark diff (327 ms)
- PASS: benchmark status (327 ms)

TEST_SUMMARY: PASS
