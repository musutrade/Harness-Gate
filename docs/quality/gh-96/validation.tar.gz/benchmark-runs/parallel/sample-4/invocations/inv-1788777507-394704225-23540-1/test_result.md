=== Verification report ===
Timestamp: 2026-09-07T10:38:27.865038191+00:00
Profile: full
Components: project

- PASS: secret scan (62 ms)
- PASS: architecture audit (23 ms) - 0 violation(s), 0 blocker(s), 0 error(s), 0 warning(s)
- PASS: benchmark diff (324 ms)
- PASS: benchmark status (324 ms)

TEST_SUMMARY: PASS
