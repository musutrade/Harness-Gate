import {
  Pricing
} from "./chunk-CPH5MTK3.js";
import "./chunk-RSTWSNOR.js";

// src/app/pricing.spec.ts
import { TestBed } from "@angular/core/testing";
describe("Pricing", () => {
  it("quotes a small order", () => {
    expect(TestBed.inject(Pricing).quote(2)).toBe(20);
  });
});
describe("Acceptance discount branch", () => {
  it("quotes a bulk order", () => {
    expect(TestBed.inject(Pricing).quote(10)).toBe(80);
  });
});
//# sourceMappingURL=spec-app-pricing.js.map
