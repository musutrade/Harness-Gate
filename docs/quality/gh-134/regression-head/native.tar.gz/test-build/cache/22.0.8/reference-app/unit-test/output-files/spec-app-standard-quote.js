import {
  StandardQuote
} from "./chunk-PVLHSREE.js";
import {
  PriorityQuote
} from "./chunk-JQCXD5YC.js";
import "./chunk-RSTWSNOR.js";

// src/app/standard-quote.spec.ts
it("keeps same-named methods on distinct classes", () => {
  expect(new StandardQuote().quote()).toBe(42);
  expect(new PriorityQuote().quote()).toBe(84);
});
//# sourceMappingURL=spec-app-standard-quote.js.map
