// src/app/details/details.ts
import { Component } from "@angular/core";
import * as i0 from "@angular/core";
var Details = class _Details {
  static \u0275fac = function Details_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Details)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _Details, selectors: [["app-details"]], decls: 4, vars: 0, template: function Details_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275domElementStart(0, "h2");
      i0.\u0275\u0275text(1, "Provider contract");
      i0.\u0275\u0275domElementEnd();
      i0.\u0275\u0275domElementStart(2, "p");
      i0.\u0275\u0275text(3, "The generated client describes the Rust provider quote endpoint.");
      i0.\u0275\u0275domElementEnd();
    }
  }, encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Details, [{
    type: Component,
    args: [{ selector: "app-details", imports: [], template: "<h2>Provider contract</h2>\n<p>The generated client describes the Rust provider quote endpoint.</p>\n" }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(Details, { className: "Details", filePath: "src/app/details/details.ts", lineNumber: 9 });
})();

export {
  Details
};
//# sourceMappingURL=chunk-37R5IX7V.js.map
