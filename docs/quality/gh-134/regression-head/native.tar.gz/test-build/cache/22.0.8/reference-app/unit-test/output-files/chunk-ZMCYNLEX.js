import {
  Details
} from "./chunk-37R5IX7V.js";
import "./chunk-RSTWSNOR.js";
export {
  Details
};
//# sourceMappingURL=chunk-ZMCYNLEX.js.map
