import {
  Details
} from "./chunk-37R5IX7V.js";
import "./chunk-RSTWSNOR.js";

// src/app/details/details.spec.ts
import { TestBed } from "@angular/core/testing";
describe("Details", () => {
  let component;
  let fixture;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Details]
    }).compileComponents();
    fixture = TestBed.createComponent(Details);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });
  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
//# sourceMappingURL=spec-app-details-details.js.map
