import {
  PriorityQuote
} from "./chunk-JQCXD5YC.js";
import "./chunk-RSTWSNOR.js";

// src/app/priority-quote.spec.ts
describe("PriorityQuote", () => {
  it("should create an instance", () => {
    expect(new PriorityQuote()).toBeTruthy();
  });
});
//# sourceMappingURL=spec-app-priority-quote.js.map
