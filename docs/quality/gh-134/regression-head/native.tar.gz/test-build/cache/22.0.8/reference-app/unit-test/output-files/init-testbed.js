import {
  __decorateElement,
  __decoratorStart,
  __runInitializers
} from "./chunk-RSTWSNOR.js";

// angular:test-bed-init:angular:test-bed-init
import { NgModule, provideZoneChangeDetection } from "@angular/core";
import { getTestBed, \u0275getCleanupHook as getCleanupHook, TestComponentRenderer } from "@angular/core/testing";
import { BrowserTestingModule, platformBrowserTesting } from "@angular/platform-browser/testing";
import { \u0275getDOM } from "@angular/common";
import { afterEach, beforeEach } from "vitest";
var providers = [];
beforeEach(getCleanupHook(false));
afterEach(getCleanupHook(true));
var DynamicDOMTestComponentRenderer = class extends TestComponentRenderer {
  insertRootElement(rootElId, tagName = "div") {
    this.removeAllRootElements();
    const dom = \u0275getDOM();
    const doc = dom.getDefaultDocument();
    if (doc && doc.body) {
      const rootElement = doc.createElement(tagName);
      rootElement.setAttribute("id", rootElId);
      doc.body.appendChild(rootElement);
    }
  }
  removeAllRootElements() {
    const dom = \u0275getDOM();
    const doc = dom.getDefaultDocument();
    if (doc && typeof doc.querySelectorAll === "function") {
      const oldRoots = doc.querySelectorAll("[id^=root]");
      for (let i = 0; i < oldRoots.length; i++) {
        dom.remove(oldRoots[i]);
      }
    }
  }
};
var ANGULAR_TESTBED_SETUP = /* @__PURE__ */ Symbol.for("@angular/cli/testbed-setup");
var _TestModule_decorators, _init;
if (!globalThis[ANGULAR_TESTBED_SETUP]) {
  globalThis[ANGULAR_TESTBED_SETUP] = true;
  _TestModule_decorators = [NgModule({
    providers: [
      ...typeof Zone !== "undefined" ? [provideZoneChangeDetection()] : [],
      ...providers,
      { provide: TestComponentRenderer, useClass: DynamicDOMTestComponentRenderer }
    ]
  })];
  class TestModule {
  }
  _init = __decoratorStart(null);
  TestModule = __decorateElement(_init, 0, "TestModule", _TestModule_decorators, TestModule);
  __runInitializers(_init, 1, TestModule);
  getTestBed().initTestEnvironment([BrowserTestingModule, TestModule], platformBrowserTesting(), {
    errorOnUnknownElements: true,
    errorOnUnknownProperties: true
  });
}
//# sourceMappingURL=init-testbed.js.map
