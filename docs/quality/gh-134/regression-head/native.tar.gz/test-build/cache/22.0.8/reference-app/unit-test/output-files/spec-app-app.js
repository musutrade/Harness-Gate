import {
  Pricing
} from "./chunk-CPH5MTK3.js";
import {
  StandardQuote
} from "./chunk-PVLHSREE.js";
import {
  PriorityQuote
} from "./chunk-JQCXD5YC.js";
import "./chunk-RSTWSNOR.js";

// src/app/app.spec.ts
import { TestBed } from "@angular/core/testing";
import { provideRouter } from "@angular/router";
import { RouterTestingHarness } from "@angular/router/testing";

// src/app/app.ts
import { Component, inject } from "@angular/core";
import { RouterLink, RouterOutlet } from "@angular/router";
import * as i0 from "@angular/core";
var App = class _App {
  amount = inject(Pricing).quote(2);
  standard = new StandardQuote().quote();
  priority = new PriorityQuote().quote();
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 9, vars: 3, consts: [["routerLink", "/details"]], template: function App_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "h1");
      i0.\u0275\u0275text(1, "Angular reference fixture");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(2, "p");
      i0.\u0275\u0275text(3);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(4, "p");
      i0.\u0275\u0275text(5);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(6, "a", 0);
      i0.\u0275\u0275text(7, "Provider details");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275element(8, "router-outlet");
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275textInterpolate1("Small order: ", ctx.amount);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate2("Standard: ", ctx.standard, "; priority: ", ctx.priority);
    }
  }, dependencies: [RouterLink, RouterOutlet], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(App, [{
    type: Component,
    args: [{ selector: "app-root", imports: [RouterLink, RouterOutlet], template: '<h1>Angular reference fixture</h1>\n<p>Small order: {{ amount }}</p>\n<p>Standard: {{ standard }}; priority: {{ priority }}</p>\n<a routerLink="/details">Provider details</a>\n<router-outlet />\n' }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(App, { className: "App", filePath: "src/app/app.ts", lineNumber: 13 });
})();

// src/app/app.routes.ts
var routes = [
  { path: "details", loadComponent: () => import("./chunk-ZMCYNLEX.js").then((m) => m.Details) }
];

// src/app/app.spec.ts
it("renders the external template", async () => {
  TestBed.configureTestingModule({ providers: [provideRouter(routes)] });
  const fixture = TestBed.createComponent(App);
  await fixture.whenStable();
  expect(fixture.nativeElement.textContent).toContain("Small order: 20");
});
it("loads the lazy route", async () => {
  TestBed.configureTestingModule({ providers: [provideRouter(routes)] });
  const harness = await RouterTestingHarness.create();
  await harness.navigateByUrl("/details");
  expect(harness.routeNativeElement?.textContent).toContain("Provider contract");
});
//# sourceMappingURL=spec-app-app.js.map
