// src/app/priority-quote.ts
var PriorityQuote = class {
  quote() {
    return 84;
  }
};

export {
  PriorityQuote
};
//# sourceMappingURL=chunk-JQCXD5YC.js.map
