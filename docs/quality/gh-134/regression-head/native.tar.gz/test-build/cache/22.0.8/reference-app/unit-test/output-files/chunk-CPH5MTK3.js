// src/app/pricing.ts
import { Injectable } from "@angular/core";
import * as i0 from "@angular/core";
var Pricing = class _Pricing {
  quote(quantity) {
    if (quantity < 0) {
      throw new Error("Quantity must be nonnegative");
    }
    if (quantity >= 10) {
      return quantity * 8;
    }
    return quantity * 10;
  }
  static \u0275fac = function Pricing_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Pricing)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _Pricing, factory: _Pricing.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Pricing, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

export {
  Pricing
};
//# sourceMappingURL=chunk-CPH5MTK3.js.map
