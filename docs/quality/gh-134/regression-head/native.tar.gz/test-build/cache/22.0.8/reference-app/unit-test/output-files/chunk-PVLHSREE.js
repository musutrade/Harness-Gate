// src/app/standard-quote.ts
var StandardQuote = class {
  quote() {
    return 42;
  }
};

export {
  StandardQuote
};
//# sourceMappingURL=chunk-PVLHSREE.js.map
