import { TestBed } from '@angular/core/testing';
import { Pricing } from './pricing';

describe('Pricing', () => {
  it('quotes a small order', () => {
    expect(TestBed.inject(Pricing).quote(2)).toBe(20);
  });
});

describe('Acceptance discount branch', () => {
  it('quotes a bulk order', () => {
    expect(TestBed.inject(Pricing).quote(10)).toBe(80);
  });
});

describe('Acceptance compatible change', () => {
  it('quotes another small order', () => {
    expect(TestBed.inject(Pricing).quote(3)).toBe(30);
  });
});
