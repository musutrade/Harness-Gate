import json,os,pathlib,subprocess,time
root=pathlib.Path.cwd(); out=root/'target/gh-230/final-checks';env=os.environ.copy()
for key in list(env):
    if key.lower().endswith('_proxy'):env.pop(key)
overrides={'CARGO_TARGET_DIR':str(root/'target/gh-230/cargo'),'TMPDIR':str(out/'tmp'),'GIT_CEILING_DIRECTORIES':str(out/'tmp'),'GIT_DIR':str(root/'target/gh-230/continued/git-metadata'),'GIT_WORK_TREE':str(root),'OPENSPEC_TELEMETRY':'0'}
env.update(overrides); records=[]
for name,command in [('docs-final',['python3','tools/quality/docs_consistency.py','--output','target/quality/docs-consistency.json']),('openspec-final',['openspec','validate','package-official-rust-collector-for-independent-delivery','--strict','--no-interactive']),('diff-final',['git','--git-dir=target/gh-230/continued/git-metadata','--work-tree=.','diff','--check'])]:
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append(dict(command=command,environment=overrides,proxy_environment_removed=True,exit_code=result.returncode,wall_seconds=time.monotonic()-start,log=name+'.log'))
    (out/'final-doc-checks.json').write_text(json.dumps(records,indent=2)+'\n');print(name,result.returncode,flush=True)
