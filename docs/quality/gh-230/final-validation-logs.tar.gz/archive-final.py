import hashlib,json,pathlib,tarfile
root=pathlib.Path.cwd(); dest=root/'docs/quality/gh-230'; inputs={}
def add(path,prefix):
    for p in sorted(path.rglob('*')) if path.is_dir() else [path]:
        rel=p.relative_to(path) if path.is_dir() else pathlib.Path(p.name)
        if any(x in rel.parts for x in ('relocated-runtime','__pycache__')) or p.name.endswith('.pem') or p.name=='runner.token': continue
        if p.is_file() and not p.is_symlink(): inputs[str(pathlib.Path(prefix)/rel)]=p
add(root/'target/gh-230/clean-host-acceptance','clean-host')
for name in ('final-acceptance','final-acceptance-v2','final-acceptance-v3'):
    directory=root/'target/gh-230'/name
    for p in directory.iterdir():
        if p.is_file() and p.suffix in ('.py','.json'): add(p,name)
    if (directory/'logs').exists(): add(directory/'logs',name+'/logs')
    if (directory/'host-commands').exists(): add(directory/'host-commands',name+'/host-commands')
    if (directory/'runtime/runtime.json').exists(): add(directory/'runtime/runtime.json',name+'/runtime')
release=root/'target/gh-230/final-acceptance-v3/candidate-release'
for p in release.iterdir():
    if p.name!='collector.tar': add(p,'candidate-release')
for name in ('core-0.4.0-recovery.md','sandbox-recovery.md','image-inspect.json','run-container.sh'):
    add(root/'target/gh-230/operator-acceptance'/name,'operator')
core=root/'target/symphony-inputs/core-v0.4.0'
for p in core.iterdir():
    if p.suffix in ('.json','.crt','.sig','.log') or p.name in ('SHA256SUMS','verification-logs'): add(p,'official-core/'+p.name if p.is_dir() else 'official-core')
for name in ('rust_collector_delivery.py','rust_collector_project.py','rust_collector_entry.py','build_rust_collector.py','tests/rust_collector_clean_host.py','tests/rust_collector_config_fixture.py','tests/test_rust_collector_runtime.py','schema/rust-project-collector-binding.schema.json'):
    add(root/'tools/quality'/name,'source/'+str(pathlib.Path(name).parent))
inventory={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in inputs.items()}
archive=dest/'clean-host-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
    for name,p in inputs.items(): t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
    assert len(t.getmembers())==len(inventory)
    for item in t:
        data=t.extractfile(item).read(); assert hashlib.sha256(data).hexdigest()==inventory[item.name]['sha256']
(dest/'clean-host-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
receipt={'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(inventory),'uncompressed_file_bytes':sum(i['bytes'] for i in inventory.values()),'all_file_hashes_verified_after_archive':True,'exclusions':['duplicated relocated runtime (inventory retained)','disposable signer private PEM keys','Python bytecode','runtime distribution tar (package hash and inventory retained)'],'scope':'Fresh original fixture captures, retained executables/profiles/exports/seals, complete reexports, configured Core decisions, raw strace, commands, costs, genuine failures, source snapshots; no operator runner secret.'}
(dest/'clean-host-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
for name in ('manifest.json','matrix.json'):
    (dest/('fixture-'+name)).write_bytes((root/'target/gh-230/clean-host-acceptance/configured'/name).read_bytes())
for name in ('producer-counts.json','setup-cost-measured.json'):
    (dest/name).write_bytes((root/'target/gh-230/final-acceptance-v3'/name).read_bytes())
