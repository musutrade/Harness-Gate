import json, os, pathlib, subprocess, time
root=pathlib.Path.cwd()
out=root/'target/gh-230/final-checks'
env=os.environ.copy()
for k in list(env):
    if k.lower().endswith('_proxy'): env.pop(k)
overrides={'CARGO_TARGET_DIR':str(root/'target/gh-230/cargo'), 'TMPDIR':str(out/'tmp'), 'GIT_CEILING_DIRECTORIES':str(out/'tmp'),
'RUST_COLLECTOR_RUNTIME':str(root/'target/gh-230/final-acceptance-v3/runtime'),
'RUST_COLLECTOR_TEST_VENDOR':str(root/'target/gh-230/continued/vendor'),
'HARNESS_GATE_NATIVE_POLICY_BINARY':str(root/'target/symphony-inputs/core-v0.4.0/harness-gate-linux-amd64'),
'NATIVE_DRIVER':str(root/'target/gh-230/operator-native-runtime/build/debug/harness-gate-rust-native-driver'),
'NATIVE_DRIVER_SYSROOT':subprocess.check_output(['rustc','--print','sysroot'], text=True).strip(), 'OPENSPEC_TELEMETRY':'0'}
env.update(overrides)
commands=[('fmt',['cargo','fmt','--manifest-path','tools/harness-gate/Cargo.toml','--','--check']),
('clippy',['cargo','clippy','--manifest-path','tools/harness-gate/Cargo.toml','--all-targets','--','-D','warnings']),
('python',['python3','-m','unittest','discover','-s','tools/quality/tests','-v']),
('release-python',['python3','-m','unittest','discover','-s','tools/release/tests','-v'])]
records=[]
for name, command in commands:
    started=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    records.append(dict(command=command, environment=overrides, proxy_environment_removed=True, exit_code=result.returncode, wall_seconds=time.monotonic()-started, log=name+'.log'))
    (out/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name, result.returncode, flush=True)
