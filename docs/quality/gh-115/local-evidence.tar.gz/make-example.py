import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path('tools/quality/tests').resolve()))
from test_policy_ratchet import RatchetTests
fixture = RatchetTests()
fixture.setUp()
try:
    for index in range(4):
        fixture.values(64, 55, index)
        fixture.change(index=index)
    new = fixture.add_subject()
    next(m for m in new['metrics'] if m['name'] == 'risk.crap')['value']['value'] = '31'
    report = fixture.evaluate()
    assert report['aggregate']['state'] == 'fail'
    assert [r['record']['ratchet']['debt'] for r in report['results']] == ['improved'] * 4 + ['new']
    Path('target/quality/gh-115/ratchet-example.json').write_text(json.dumps(report, indent=2) + '\n')
finally:
    fixture.doCleanups()
