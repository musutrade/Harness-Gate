import json
import os
from pathlib import Path
import subprocess
import time
root = Path.cwd()
out = root / 'target/quality/gh-115'
env = dict(os.environ, CARGO_TARGET_DIR=str(root / 'target/gh-115-cargo'))
commands = [
('nextest', 'cargo nextest run --manifest-path tools/harness-gate/Cargo.toml --locked'),
('fmt', 'cargo fmt --manifest-path tools/harness-gate/Cargo.toml -- --check'),
('clippy', 'cargo clippy --manifest-path tools/harness-gate/Cargo.toml --all-targets -- -D warnings'),
('python', 'python3 -m unittest discover -s tools/quality/tests -v'),
]
checks=[]
for name, command in commands:
    start=time.monotonic()
    with (out / (name+'.log')).open('w') as log:
        result=subprocess.run(command.split(), stdout=log, stderr=subprocess.STDOUT, env=env)
    checks.append({'command':command, 'exit_code':result.returncode,
                   'duration_seconds':round(time.monotonic()-start,2),'log':name+'.log'})
    (out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks[-1]),flush=True)
