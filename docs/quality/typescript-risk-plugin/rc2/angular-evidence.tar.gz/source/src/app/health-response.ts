export interface HealthResponse {
  status: 'ok' | 'unavailable';
  database: 'ok' | 'unavailable';
}
