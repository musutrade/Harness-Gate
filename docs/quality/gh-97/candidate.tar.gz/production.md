# Production coverage candidate

Status: pass; line threshold: 80.0%

| Boundary | Lines | Functions | Regions | Status |
| --- | ---: | ---: | ---: | --- |
| app | 317/390 | 14/24 | 462/619 | pass |
| audit | 811/975 | 98/120 | 1312/1630 | pass |
| cli | 8/9 | 1/1 | 8/10 | informational |
| compat | 176/196 | 12/21 | 279/351 | informational |
| config | 2348/2667 | 175/195 | 3174/3682 | pass |
| doctor | 239/252 | 28/33 | 381/416 | pass |
| error | 13/13 | 2/2 | 19/19 | informational |
| failure | 72/84 | 4/4 | 96/123 | informational |
| lib | 0/0 | 0/0 | 0/0 | informational |
| main | 10/10 | 1/1 | 13/13 | informational |
| net_policy | 43/43 | 8/8 | 74/76 | informational |
| preset | 129/196 | 13/30 | 252/426 | informational |
| process | 1182/1382 | 87/134 | 1575/1877 | pass |
| project | 341/422 | 38/57 | 519/692 | pass |
| scope | 98/113 | 6/8 | 137/157 | pass |
| secrets | 400/433 | 47/54 | 605/692 | pass |
| service-core | 1163/1367 | 98/147 | 1645/2093 | pass |
| service-adapters | 94/110 | 9/13 | 111/143 | informational |
| ui | 54/74 | 13/15 | 67/107 | informational |
| utils | 286/335 | 33/60 | 462/615 | informational |
| verify | 2945/3469 | 239/342 | 4229/5179 | pass |
| aggregate | 9844/11470 | 830/1114 | 14039/17037 | pass |
