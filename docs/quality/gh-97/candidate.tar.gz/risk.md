# Candidate function risk

Base: `381d5f418655969d29b81f89069845e6667f35c9`

Head: `381d5f418655969d29b81f89069845e6667f35c9`

Identities: 212; failures: 0.

Scope: six GH-94 files. Raw counters, exact rational CRAP and historical debt are retained in head-risk.json. Branch coverage is unsupported. This candidate is not an accepted baseline.
