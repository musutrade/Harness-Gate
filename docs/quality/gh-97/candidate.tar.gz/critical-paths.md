# Critical Path Evidence

- `process.timeout`: pass 
- `process.cancellation`: pass 
- `process.tree_cleanup`: pass 
- `step.non_zero`: pass 
- `service.environment_failure`: pass 
- `gate.failure_report`: pass 
- `config.invalid`: pass 
- `parser.failure`: pass 
- `report.write_failure`: pass 
- `report.integrity`: pass 
- `parser.json_false_positive`: pass 
- `service.lease_ownership`: pass 

12/12 applicable paths passed.
