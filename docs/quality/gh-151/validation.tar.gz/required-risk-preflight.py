"""Apply Collector.risk's existing path boundary to the uncommitted candidate.

Git metadata is read-only, so include untracked source files explicitly.
This is a boundary preflight, not a full required collection.
"""
import subprocess
from production_coverage import require
from source_measure import HOTSPOTS

changed = subprocess.check_output([
    "git", "diff", "--name-only", "9a73ae0f7c61d804fbfc2fe35eac8377eb1fc22e",
    "--", "tools/harness-gate/src"], text=True).splitlines()
changed += subprocess.check_output([
    "git", "ls-files", "--others", "--exclude-standard", "--",
    "tools/harness-gate/src"], text=True).splitlines()
unsupported = sorted(p for p in changed if p.endswith('.rs') and
                     p.removeprefix('tools/harness-gate/src/') not in HOTSPOTS)
require(not unsupported,
        'production changes outside supported risk series; measurement review required: '
        + ', '.join(unsupported))
