import json
import os
from pathlib import Path
import subprocess
import sys
import time

commands = {
    'nextest': ['cargo', 'nextest', 'run', '--manifest-path', 'tools/harness-gate/Cargo.toml', '--locked'],
    'fmt': ['cargo', 'fmt', '--manifest-path', 'tools/harness-gate/Cargo.toml', '--', '--check'],
    'clippy': ['cargo', 'clippy', '--manifest-path', 'tools/harness-gate/Cargo.toml', '--all-targets', '--', '-D', 'warnings'],
    'python': ['python3', '-m', 'unittest', 'discover', '-s', 'tools/quality/tests', '-v'],
    'docs': ['python3', 'tools/quality/docs_consistency.py', '--output', 'target/quality/docs-consistency.json'],
}
name = sys.argv[1]
local = len(sys.argv) > 2
label = name + ('-local-target' if local else '')
root = Path('target/quality/gh-113')
env = dict(os.environ)
if local:
    env['CARGO_TARGET_DIR'] = str(Path('target/gh-113-cargo').resolve())
start = time.monotonic()
with (root / (label + '.log')).open('w') as log:
    result = subprocess.run(commands[name], stdout=log, stderr=subprocess.STDOUT, env=env)
record = {'command': ' '.join(commands[name]), 'exit_code': result.returncode,
          'duration_seconds': round(time.monotonic() - start, 2), 'log': label + '.log',
          'environment_override': {'CARGO_TARGET_DIR': env['CARGO_TARGET_DIR']} if local else {}}
(root / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print('\n'.join((root / (label + '.log')).read_text().splitlines()[-5:]))
if name == 'docs':
    import shutil
    shutil.copyfile('target/quality/docs-consistency.json', root / (label + '-report.json'))
