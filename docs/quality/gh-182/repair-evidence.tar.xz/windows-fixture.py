from pathlib import Path
import runpy
import sys
original = Path.write_text
def windows_write(self, data, encoding=None, errors=None, newline=None):
    return original(self, data, encoding=encoding, errors=errors, newline="\r\n")
Path.write_text = windows_write
sys.argv = ["acceptance.py", "--harness-gate", "/tmp/gh182-cargo/debug/harness-gate", "--output", "target/quality/gh-182-repair/crlf-after"]
runpy.run_path("tools/quality/fixtures/workflow/baseline/acceptance.py", run_name="__main__")
