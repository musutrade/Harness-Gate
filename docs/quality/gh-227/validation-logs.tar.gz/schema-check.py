import json
import sys
from pathlib import Path
import jsonschema
sys.path.insert(0, 'tools/quality/tests')
from test_rust_collector_contract import fixture
schema = json.loads(Path('tools/quality/schema/rust-collector-delivery.schema.json').read_text())
jsonschema.Draft7Validator.check_schema(schema)
manifest, matrix, observed = fixture()
for definition, value in [('Manifest', manifest), ('Matrix', matrix), ('Environment', observed)]:
    rooted = dict(schema, **{'$ref': '#/definitions/' + definition})
    jsonschema.Draft7Validator(rooted).validate(value)
    print(definition + ': draft-07 schema and synthetic fixture valid (not native acceptance)')
