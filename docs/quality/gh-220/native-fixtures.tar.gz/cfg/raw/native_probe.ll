; ModuleID = 'native_probe.bf029131146f0e19-cgu.0'
source_filename = "native_probe.bf029131146f0e19-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

$__covrec_DC784632B386F1D1u = comdat any

$__covrec_7A65FBF075F2B412u = comdat any

$__covrec_E30B13AD0EA68593u = comdat any

$__covrec_3A9731A30970E5BAu = comdat any

$__covrec_1E9D75B9D76A07E1u = comdat any

$__covrec_422492A1C494FF24u = comdat any

$__covrec_4E03717177C9917Du = comdat any

$__covrec_40BECCCE231B7F7Du = comdat any

$__covrec_70D0D4EFBD7623F3u = comdat any

$__covrec_9A49A959465DD27Bu = comdat any

$__profc__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_ = comdat nodeduplicate

$__profc__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_ = comdat nodeduplicate

$__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_ = comdat nodeduplicate

$__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_ = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe11conditional = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe4main = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe5first = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe6future = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe6second = comdat nodeduplicate

$__profc__RNvCsgoJZQLhOXBl_12native_probe7closure = comdat nodeduplicate

$__llvm_profile_filename = comdat any

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCsgoJZQLhOXBl_12native_probe, ptr @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe, ptr @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe }>, align 8
@alloc_32a1fd3b71af0e58a3b40a4f8c2e3027 = private unnamed_addr constant [10 x i8] c"source.rs\00", align 1
@alloc_418845e06df98c180f4078be72683e4a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_32a1fd3b71af0e58a3b40a4f8c2e3027, [16 x i8] c"\09\00\00\00\00\00\00\00\0D\00\00\00$\00\00\00" }>, align 8
@__covrec_DC784632B386F1D1u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [19 x i8] }> <{ i64 -2560219204585852463, i32 19, i64 -5634895652803790168, i64 3994344957990049024, [19 x i8] c"\01\01\00\03\01\16\01\00\1D\01\00 \00%\01\00&\00'" }>, section "__llvm_covfun", comdat, align 8
@__covrec_7A65FBF075F2B412u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [19 x i8] }> <{ i64 8819732455464547346, i32 19, i64 -5634895652803790168, i64 3994344957990049024, [19 x i8] c"\01\01\00\03\01\16\01\00\1D\01\00 \00%\01\00&\00'" }>, section "__llvm_covfun", comdat, align 8
@__covrec_E30B13AD0EA68593u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [31 x i8] }> <{ i64 -2086552368360028781, i32 31, i64 3622086691364306881, i64 3994344957990049024, [31 x i8] c"\01\01\01\01\05\05\01\0D$\00%\01\01\08\00\0D\05\00\10\00\11\02\00\1B\00\1C\01\01\01\00\02" }>, section "__llvm_covfun", comdat, align 8
@__covrec_3A9731A30970E5BAu = linkonce_odr hidden constant <{ i64, i32, i64, i64, [26 x i8] }> <{ i64 4221897751990953402, i32 26, i64 7310705510861867683, i64 3994344957990049024, [26 x i8] c"\01\01\01\01\05\04\01\12\1A\00\1F\05\00\22\00#\02\00-\00.\01\00/\000" }>, section "__llvm_covfun", comdat, align 8
@__covrec_1E9D75B9D76A07E1u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [19 x i8] }> <{ i64 2206048833524860897, i32 19, i64 -1844140391571991213, i64 3994344957990049024, [19 x i8] c"\01\01\00\03\01\19\01\00\17\01\00\1A\00\1B\01\00\1C\00\1D" }>, section "__llvm_covfun", comdat, align 8
@__covrec_422492A1C494FF24u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [54 x i8] }> <{ i64 4766095529150316324, i32 54, i64 6754060034207391137, i64 3994344957990049024, [54 x i8] c"\01\01\00\0A\01!\01\00\0A\01\01\09\00\12\01\00\15\00\1B\01\01\05\00\0C\01\01\05\00\0A\01\01\05\00\0B\01\01\05\00\0C\01\01\05\00\0C\01\02\05\00\10\01\01\01\00\02" }>, section "__llvm_covfun", comdat, align 8
@__covrec_4E03717177C9917Du = linkonce_odr hidden constant <{ i64, i32, i64, i64, [31 x i8] }> <{ i64 5621461492043452797, i32 31, i64 2494204997400439238, i64 3994344957990049024, [31 x i8] c"\01\01\01\01\05\05\01\05\09\00$\01\01\10\00\15\05\00\18\00\19\02\00#\00$\01\01\09\00\0A" }>, section "__llvm_covfun", comdat, align 8
@__covrec_40BECCCE231B7F7Du = linkonce_odr hidden constant <{ i64, i32, i64, i64, [9 x i8] }> <{ i64 4665391449726746493, i32 9, i64 3622086691364306881, i64 3994344957990049024, [9 x i8] c"\01\01\00\01\01\0D\01\00#" }>, section "__llvm_covfun", comdat, align 8
@__covrec_70D0D4EFBD7623F3u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [31 x i8] }> <{ i64 8129231453544653811, i32 31, i64 -6275165969871587816, i64 3994344957990049024, [31 x i8] c"\01\01\01\01\05\05\01\05\09\00$\01\01\10\00\15\05\00\18\00\19\02\00#\00$\01\01\09\00\0A" }>, section "__llvm_covfun", comdat, align 8
@__covrec_9A49A959465DD27Bu = linkonce_odr hidden constant <{ i64, i32, i64, i64, [24 x i8] }> <{ i64 -7329140717671034245, i32 24, i64 7310705510861867683, i64 3994344957990049024, [24 x i8] c"\01\01\00\04\01\11\01\00\1E\01\01\09\00\11\01\01\05\00\0F\01\01\01\00\02" }>, section "__llvm_covfun", comdat, align 8
@__llvm_coverage_mapping = private constant { { i32, i32, i32, i32 }, [103 x i8] } { { i32, i32, i32, i32 } { i32 0, i32 103, i32 0, i32 6 }, [103 x i8] c"\02\B8\01cx\DA\B5\CC\CB\0D\830\10\05\C0\8A\9CG\08=\90\0Ar\8Ee\16\83\90?\DA\B7\80L\F5\91\D2\03\C7\B9\CC\07)\1B&9\1C9\E1,\BA\B1\FA \04[\AAK\C9\0D\E3\DB\F5}\07\F3\1A\C5\10\97\BF\B2\B7\F5\10gB#,U\0E\FB+\\\FAD\98#\D4\9F\DF{Z\B0\EC\1A\E4\A1\FC\01\D5\8EB\00" }, section "__llvm_covmap", align 8
@__profc__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_ = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_ = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 -2560219204585852463, i64 -5634895652803790168, i64 sub (i64 ptrtoint (ptr @__profc__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_ to i64), i64 ptrtoint (ptr @__profd__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_ to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_), align 8
@__profc__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_ = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_ = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 8819732455464547346, i64 -5634895652803790168, i64 sub (i64 ptrtoint (ptr @__profc__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_ to i64), i64 ptrtoint (ptr @__profd__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_ to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_), align 8
@__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_ = private global [2 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_ = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 -2086552368360028781, i64 3622086691364306881, i64 sub (i64 ptrtoint (ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_ to i64), i64 ptrtoint (ptr @__profd__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_ to i64)), i64 0, ptr null, ptr null, i32 2, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_), align 8
@__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_ = private global [2 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_ = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 4221897751990953402, i64 7310705510861867683, i64 sub (i64 ptrtoint (ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_ to i64), i64 ptrtoint (ptr @__profd__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_ to i64)), i64 0, ptr null, ptr null, i32 2, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe11conditional = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe11conditional = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 2206048833524860897, i64 -1844140391571991213, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe11conditional to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe11conditional to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe11conditional), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe4main = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe4main = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 4766095529150316324, i64 6754060034207391137, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe4main to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe4main to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe4main), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe5first = private global [2 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe5first = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 5621461492043452797, i64 2494204997400439238, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe5first to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe5first to i64)), i64 0, ptr null, ptr null, i32 2, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe5first), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe6future = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe6future = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 4665391449726746493, i64 3622086691364306881, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe6future to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe6future to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe6future), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe6second = private global [2 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe6second = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 8129231453544653811, i64 -6275165969871587816, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe6second to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe6second to i64)), i64 0, ptr null, ptr null, i32 2, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe6second), align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe7closure = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe7closure = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 -7329140717671034245, i64 7310705510861867683, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe7closure to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe7closure to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe7closure), align 8
@__llvm_prf_nm = private constant [134 x i8] c"\AE\03\82\01x\DA\8D\CF=\0B\C20\10\80a\FCG\A6~tOqP\A4\A2\93\B8\1C1^\DB\83\F4N\92k\7F\BF\08\15\9C\9A\EE\CF\F0\BEp;\D6c\95Z9=\AE\E7\EEr\B7\01L\C1NiDxGyb\D9\22c$\DF\1Dl\01+X\CAu\E2u5\EF\F7\CD\A0C\C4\B5\DD,\D1\A5\0F\92\FE\F8,6\C6\0B\BFHI\D8\85\AC\DE\F6\8E8\ABv\0D\C5\A4Y6]\E5]\C2oc\D6\FD\BE?\CE8\9AX", section "__llvm_prf_names", align 1
@llvm.compiler.used = appending global [10 x ptr] [ptr @__profd__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_, ptr @__profd__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_, ptr @__profd__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_, ptr @__profd__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe11conditional, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe4main, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe5first, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe6future, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe6second, ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe7closure], section "llvm.metadata"
@llvm.used = appending global [12 x ptr] [ptr @__covrec_DC784632B386F1D1u, ptr @__covrec_7A65FBF075F2B412u, ptr @__covrec_E30B13AD0EA68593u, ptr @__covrec_3A9731A30970E5BAu, ptr @__covrec_1E9D75B9D76A07E1u, ptr @__covrec_422492A1C494FF24u, ptr @__covrec_4E03717177C9917Du, ptr @__covrec_40BECCCE231B7F7Du, ptr @__covrec_70D0D4EFBD7623F3u, ptr @__covrec_9A49A959465DD27Bu, ptr @__llvm_coverage_mapping, ptr @__llvm_prf_nm], section "llvm.metadata"
@__llvm_profile_filename = hidden constant [22 x i8] c"default_%m_%p.profraw\00", comdat

; native_probe::generic::<u8>
; Function Attrs: nonlazybind uwtable
define hidden i8 @_RINvCsgoJZQLhOXBl_12native_probe7generichEB2_(i8 %value) unnamed_addr #0 {
start:
  %0 = atomicrmw add ptr @__profc__RINvCsgoJZQLhOXBl_12native_probe7generichEB2_, i64 1 monotonic, align 8
  ret i8 %value
}

; native_probe::generic::<u16>
; Function Attrs: nonlazybind uwtable
define hidden i16 @_RINvCsgoJZQLhOXBl_12native_probe7generictEB2_(i16 %value) unnamed_addr #0 {
start:
  %0 = atomicrmw add ptr @__profc__RINvCsgoJZQLhOXBl_12native_probe7generictEB2_, i64 1 monotonic, align 8
  ret i16 %value
}

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECsgoJZQLhOXBl_12native_probe(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::ptr::drop_glue::<native_probe::future::{closure#0}>
; Function Attrs: nonlazybind uwtable
define hidden void @_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvCsgoJZQLhOXBl_12native_probe6future0EBF_(ptr %_1) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds i8, ptr %_1, i64 1
  %1 = load i8, ptr %0, align 1
  %_6 = zext i8 %1 to i32
  %2 = icmp eq i32 %_6, 0
  br i1 %2, label %bb2, label %bb4

bb2:                                              ; preds = %start
  ret void

bb4:                                              ; preds = %start
  ret void
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define hidden void @_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgoJZQLhOXBl_12native_probe(ptr %f) unnamed_addr #1 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %f)
  call void asm sideeffect "", "~{memory}"(), !srcloc !4
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe(ptr align 8 %_1) unnamed_addr #2 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgoJZQLhOXBl_12native_probe(ptr %_4)
; call <() as std::process::Termination>::report
  %self = call i8 @_RNvXsZ_NtCs2AWtUsOyxgP_3std7processuNtB5_11Termination6reportCsgoJZQLhOXBl_12native_probe()
  %_0 = zext i8 %self to i32
  ret i32 %_0
}

; native_probe::future::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden { i1, i8 } @_RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_(ptr %_1, ptr align 8 %_task_context) unnamed_addr #2 {
start:
  %_4 = alloca [1 x i8], align 1
  %0 = getelementptr inbounds i8, ptr %_1, i64 1
  %1 = load i8, ptr %0, align 1
  %_5 = zext i8 %1 to i32
  %2 = trunc nuw i32 %_5 to i1
  br i1 %2, label %bb5, label %bb1

bb5:                                              ; preds = %bb5, %start
  br i1 false, label %bb5, label %panic

bb1:                                              ; preds = %start
  %3 = atomicrmw add ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_, i64 1 monotonic, align 8
  %4 = load i8, ptr %_1, align 1
  %value = trunc nuw i8 %4 to i1
  br i1 %value, label %bb2, label %bb3

bb3:                                              ; preds = %bb1
  store i8 2, ptr %_4, align 1
  br label %bb4

bb2:                                              ; preds = %bb1
  %5 = atomicrmw add ptr getelementptr inbounds ([2 x i64], ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe6future0B3_, i32 0, i32 1), i64 1 monotonic, align 8
  store i8 1, ptr %_4, align 1
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %_0.1 = load i8, ptr %_4, align 1
  %6 = getelementptr inbounds i8, ptr %_1, i64 1
  store i8 1, ptr %6, align 1
  %7 = insertvalue { i1, i8 } { i1 false, i8 poison }, i8 %_0.1, 1
  ret { i1, i8 } %7

panic:                                            ; preds = %bb5
; call core::panicking::panic_const::panic_const_async_fn_resumed
  call void @_RNvNtNtCs4NRVxsYgnAr_4core9panicking11panic_const28panic_const_async_fn_resumed(ptr align 8 @alloc_418845e06df98c180f4078be72683e4a) #9
  unreachable

bb6:                                              ; No predecessors!
  unreachable
}

; native_probe::closure::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i8 @_RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_(ptr align 8 %_1) unnamed_addr #2 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = atomicrmw add ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_, i64 1 monotonic, align 8
  %_3 = load ptr, ptr %_1, align 8
  %1 = load i8, ptr %_3, align 1
  %_2 = trunc nuw i8 %1 to i1
  br i1 %_2, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 2, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %2 = atomicrmw add ptr getelementptr inbounds ([2 x i64], ptr @__profc__RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_, i32 0, i32 1), i64 1 monotonic, align 8
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %3 = load i8, ptr %_0, align 1
  ret i8 %3
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCsgoJZQLhOXBl_12native_probe(ptr %_1) unnamed_addr #2 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %0)
  ret i32 %_0
}

; native_probe::conditional
; Function Attrs: nonlazybind uwtable
define hidden i8 @_RNvCsgoJZQLhOXBl_12native_probe11conditional() unnamed_addr #0 {
start:
  %0 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe11conditional, i64 1 monotonic, align 8
  ret i8 1
}

; native_probe::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsgoJZQLhOXBl_12native_probe4main() unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
  %1 = alloca [2 x i8], align 2
  %_unpolled = alloca [2 x i8], align 1
  %2 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe4main, i64 1 monotonic, align 8
; call native_probe::future
  %3 = call i16 @_RNvCsgoJZQLhOXBl_12native_probe6future(i1 zeroext true)
  store i16 %3, ptr %1, align 2
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %_unpolled, ptr align 2 %1, i64 2, i1 false)
; invoke native_probe::closure
  %_2 = invoke i8 @_RNvCsgoJZQLhOXBl_12native_probe7closure(i1 zeroext true)
          to label %bb2 unwind label %cleanup

bb9:                                              ; preds = %cleanup
; invoke core::ptr::drop_glue::<native_probe::future::{closure#0}>
  invoke void @_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvCsgoJZQLhOXBl_12native_probe6future0EBF_(ptr %_unpolled) #10
          to label %bb10 unwind label %terminate

cleanup:                                          ; preds = %bb6, %bb5, %bb4, %bb3, %bb2, %start
  %4 = landingpad { ptr, i32 }
          cleanup
  %5 = extractvalue { ptr, i32 } %4, 0
  %6 = extractvalue { ptr, i32 } %4, 1
  store ptr %5, ptr %0, align 8
  %7 = getelementptr inbounds i8, ptr %0, i64 8
  store i32 %6, ptr %7, align 8
  br label %bb9

bb2:                                              ; preds = %start
; invoke native_probe::first
  %_3 = invoke i8 @_RNvCsgoJZQLhOXBl_12native_probe5first(i1 zeroext true)
          to label %bb3 unwind label %cleanup

bb3:                                              ; preds = %bb2
; invoke native_probe::second
  %_4 = invoke i8 @_RNvCsgoJZQLhOXBl_12native_probe6second(i1 zeroext false)
          to label %bb4 unwind label %cleanup

bb4:                                              ; preds = %bb3
; invoke native_probe::generic::<u8>
  %_5 = invoke i8 @_RINvCsgoJZQLhOXBl_12native_probe7generichEB2_(i8 1)
          to label %bb5 unwind label %cleanup

bb5:                                              ; preds = %bb4
; invoke native_probe::generic::<u16>
  %_6 = invoke i16 @_RINvCsgoJZQLhOXBl_12native_probe7generictEB2_(i16 2)
          to label %bb6 unwind label %cleanup

bb6:                                              ; preds = %bb5
; invoke native_probe::conditional
  %_7 = invoke i8 @_RNvCsgoJZQLhOXBl_12native_probe11conditional()
          to label %bb7 unwind label %cleanup

bb7:                                              ; preds = %bb6
; call core::ptr::drop_glue::<native_probe::future::{closure#0}>
  call void @_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvCsgoJZQLhOXBl_12native_probe6future0EBF_(ptr %_unpolled)
  ret void

terminate:                                        ; preds = %bb9
  %8 = landingpad { ptr, i32 }
          filter [0 x ptr] zeroinitializer
; call core::panicking::panic_in_cleanup
  call void @_RNvNtCs4NRVxsYgnAr_4core9panicking16panic_in_cleanup() #11
  unreachable

bb10:                                             ; preds = %bb9
  %9 = load ptr, ptr %0, align 8
  %10 = getelementptr inbounds i8, ptr %0, i64 8
  %11 = load i32, ptr %10, align 8
  %12 = insertvalue { ptr, i32 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i32 } %12, i32 %11, 1
  resume { ptr, i32 } %13
}

; native_probe::first
; Function Attrs: nonlazybind uwtable
define hidden i8 @_RNvCsgoJZQLhOXBl_12native_probe5first(i1 zeroext %value) unnamed_addr #0 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe5first, i64 1 monotonic, align 8
  br i1 %value, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 2, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %1 = atomicrmw add ptr getelementptr inbounds ([2 x i64], ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe5first, i32 0, i32 1), i64 1 monotonic, align 8
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  ret i8 %2
}

; native_probe::future
; Function Attrs: nonlazybind uwtable
define hidden i16 @_RNvCsgoJZQLhOXBl_12native_probe6future(i1 zeroext %value) unnamed_addr #0 {
start:
  %_0 = alloca [2 x i8], align 1
  %0 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe6future, i64 1 monotonic, align 8
  %1 = zext i1 %value to i8
  store i8 %1, ptr %_0, align 1
  %2 = getelementptr inbounds i8, ptr %_0, i64 1
  store i8 0, ptr %2, align 1
  %3 = load i16, ptr %_0, align 1
  ret i16 %3
}

; native_probe::second
; Function Attrs: nonlazybind uwtable
define hidden i8 @_RNvCsgoJZQLhOXBl_12native_probe6second(i1 zeroext %value) unnamed_addr #0 {
start:
  %_0 = alloca [1 x i8], align 1
  %0 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe6second, i64 1 monotonic, align 8
  br i1 %value, label %bb1, label %bb2

bb2:                                              ; preds = %start
  store i8 2, ptr %_0, align 1
  br label %bb3

bb1:                                              ; preds = %start
  %1 = atomicrmw add ptr getelementptr inbounds ([2 x i64], ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe6second, i32 0, i32 1), i64 1 monotonic, align 8
  store i8 1, ptr %_0, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %2 = load i8, ptr %_0, align 1
  ret i8 %2
}

; native_probe::closure
; Function Attrs: nonlazybind uwtable
define hidden i8 @_RNvCsgoJZQLhOXBl_12native_probe7closure(i1 zeroext %0) unnamed_addr #0 {
start:
  %callback = alloca [8 x i8], align 8
  %value = alloca [1 x i8], align 1
  %1 = zext i1 %0 to i8
  store i8 %1, ptr %value, align 1
  %2 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe7closure, i64 1 monotonic, align 8
  store ptr %value, ptr %callback, align 8
; call native_probe::closure::{closure#0}
  %_0 = call i8 @_RNCNvCsgoJZQLhOXBl_12native_probe7closure0B3_(ptr align 8 %callback)
  ret i8 %_0
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i8 @_RNvXsZ_NtCs2AWtUsOyxgP_3std7processuNtB5_11Termination6reportCsgoJZQLhOXBl_12native_probe() unnamed_addr #2 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define hidden void @_RNvYFEuINtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %_1) unnamed_addr #2 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %0) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; invoke std::rt::lang_start::<()>::{closure#0}
  %_0 = invoke i32 @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe(ptr align 8 %_1)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds i8, ptr %1, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6

cleanup:                                          ; preds = %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb3

bb1:                                              ; preds = %start
  ret i32 %_0
}

; Function Attrs: nounwind
declare void @llvm.instrprof.increment(ptr, i64, i32, i32) #3

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; core::panicking::panic_const::panic_const_async_fn_resumed
; Function Attrs: cold noinline noreturn nonlazybind uwtable
declare void @_RNvNtNtCs4NRVxsYgnAr_4core9panicking11panic_const28panic_const_async_fn_resumed(ptr align 8) unnamed_addr #4

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #5

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; core::panicking::panic_in_cleanup
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCs4NRVxsYgnAr_4core9panicking16panic_in_cleanup() unnamed_addr #7

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #8 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECsgoJZQLhOXBl_12native_probe(ptr @_RNvCsgoJZQLhOXBl_12native_probe4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind }
attributes #4 = { cold noinline noreturn nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { nonlazybind "target-cpu"="x86-64" }
attributes #9 = { noreturn }
attributes #10 = { cold }
attributes #11 = { cold noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 2, !"RtLibUseGOT", i32 1}
!3 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!4 = !{i64 11826712143332402}
