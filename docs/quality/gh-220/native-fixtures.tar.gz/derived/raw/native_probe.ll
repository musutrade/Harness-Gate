; ModuleID = 'native_probe.bf029131146f0e19-cgu.0'
source_filename = "native_probe.bf029131146f0e19-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

$__covrec_422492A1C494FF24u = comdat any

$__profc__RNvCsgoJZQLhOXBl_12native_probe4main = comdat nodeduplicate

$__llvm_profile_filename = comdat any

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCsgoJZQLhOXBl_12native_probe, ptr @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe, ptr @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe }>, align 8
@alloc_8821998f047ca62cad40e6bc4e4d87c4 = private unnamed_addr constant [1 x i8] c"\01", align 1
@__covrec_422492A1C494FF24u = linkonce_odr hidden constant <{ i64, i32, i64, i64, [39 x i8] }> <{ i64 4766095529150316324, i32 39, i64 6554879285751676225, i64 5632134960706124544, [39 x i8] c"\01\01\00\07\01\04\01\00\0A\01\01\09\00\0E\01\00\11\00\1D\01\00\1E\00#\01\01\05\00\19\01\00\1A\00!\01\01\01\00\02" }>, section "__llvm_covfun", comdat, align 8
@__llvm_coverage_mapping = private constant { { i32, i32, i32, i32 }, [105 x i8] } { { i32, i32, i32, i32 } { i32 0, i32 105, i32 0, i32 6 }, [105 x i8] c"\02\C0\01ex\DA\B5\CC]\0A\830\10E\E1\15\A5W\D3\EEA\D7\E0[H\06-\92\1F\E6N\14\BB\FAJ\F7\D0\C7\C3\81oA.\86$\87#\13\CE\AA;[\88B\F0\CAm\AB\E5\C24;\EF\07X\D0U\0C\EB\F6\AB\12\EC}\883\A1\11\96\1B_\FD\19?:\DE\92\DE#A\C3\99\FEG\83\B5k\94\87\F2\0B\16\90En" }, section "__llvm_covmap", align 8
@__profc__RNvCsgoJZQLhOXBl_12native_probe4main = private global [1 x i64] zeroinitializer, section "__llvm_prf_cnts", comdat, align 8
@__profd__RNvCsgoJZQLhOXBl_12native_probe4main = private global { i64, i64, i64, i64, ptr, ptr, i32, [3 x i16], i32 } { i64 4766095529150316324, i64 6554879285751676225, i64 sub (i64 ptrtoint (ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe4main to i64), i64 ptrtoint (ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe4main to i64)), i64 0, ptr null, ptr null, i32 1, [3 x i16] zeroinitializer, i32 0 }, section "__llvm_prf_data", comdat($__profc__RNvCsgoJZQLhOXBl_12native_probe4main), align 8
@__llvm_prf_nm = private constant [47 x i8] c"%-x\DA\8B\0F\F2+s.N\CF\F7\8A\0A\F4\C9\F0\8Fp\CA\8974\CAK,\C9,K\8D/(\CAOJ5\C9M\CC\CC\03\00\FC\04\0D\99", section "__llvm_prf_names", align 1
@llvm.compiler.used = appending global [1 x ptr] [ptr @__profd__RNvCsgoJZQLhOXBl_12native_probe4main], section "llvm.metadata"
@llvm.used = appending global [3 x ptr] [ptr @__covrec_422492A1C494FF24u, ptr @__llvm_coverage_mapping, ptr @__llvm_prf_nm], section "llvm.metadata"
@__llvm_profile_filename = hidden constant [22 x i8] c"default_%m_%p.profraw\00", comdat

; std::rt::lang_start::<()>
; Function Attrs: nonlazybind uwtable
define hidden i64 @_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECsgoJZQLhOXBl_12native_probe(ptr %main, i64 %argc, ptr %argv, i8 %sigpipe) unnamed_addr #0 {
start:
  %_7 = alloca [8 x i8], align 8
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call i64 @_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal(ptr %_7, ptr align 8 @vtable.0, i64 %argc, ptr %argv, i8 %sigpipe)
  ret i64 %_0
}

; core::hint::black_box::<u8>
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i8 @_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxhECsgoJZQLhOXBl_12native_probe(i8 %dummy) unnamed_addr #1 {
start:
  %0 = alloca [1 x i8], align 1
  store i8 %dummy, ptr %0, align 1
  call void asm sideeffect "", "r,~{memory}"(ptr %0), !srcloc !4
  %_0 = load i8, ptr %0, align 1
  ret i8 %_0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline nonlazybind uwtable
define hidden void @_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgoJZQLhOXBl_12native_probe(ptr %f) unnamed_addr #2 {
start:
; call <fn() as core::ops::function::FnOnce<()>>::call_once
  call void @_RNvYFEuINtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %f)
  call void asm sideeffect "", "~{memory}"(), !srcloc !4
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe(ptr align 8 %_1) unnamed_addr #1 {
start:
  %_4 = load ptr, ptr %_1, align 8
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  call void @_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgoJZQLhOXBl_12native_probe(ptr %_4)
; call <() as std::process::Termination>::report
  %self = call i8 @_RNvXsZ_NtCs2AWtUsOyxgP_3std7processuNtB5_11Termination6reportCsgoJZQLhOXBl_12native_probe()
  %_0 = zext i8 %self to i32
  ret i32 %_0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCsgoJZQLhOXBl_12native_probe(ptr %_1) unnamed_addr #1 {
start:
  %_2 = alloca [0 x i8], align 1
  %0 = load ptr, ptr %_1, align 8
; call <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
  %_0 = call i32 @_RNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %0)
  ret i32 %_0
}

; native_probe::main
; Function Attrs: nonlazybind uwtable
define hidden void @_RNvCsgoJZQLhOXBl_12native_probe4main() unnamed_addr #0 {
start:
  %0 = atomicrmw add ptr @__profc__RNvCsgoJZQLhOXBl_12native_probe4main, i64 1 monotonic, align 8
; call <native_probe::Generated as core::clone::Clone>::clone
  %value = call i8 @_RNvXCsgoJZQLhOXBl_12native_probeNtB2_9GeneratedNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneB2_(ptr @alloc_8821998f047ca62cad40e6bc4e4d87c4)
; call core::hint::black_box::<u8>
  %_3 = call i8 @_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxhECsgoJZQLhOXBl_12native_probe(i8 %value)
  ret void
}

; <native_probe::Generated as core::clone::Clone>::clone
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i8 @_RNvXCsgoJZQLhOXBl_12native_probeNtB2_9GeneratedNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneB2_(ptr %self) unnamed_addr #1 {
start:
  %_2 = load i8, ptr %self, align 1
  ret i8 %_2
}

; <() as std::process::Termination>::report
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i8 @_RNvXsZ_NtCs2AWtUsOyxgP_3std7processuNtB5_11Termination6reportCsgoJZQLhOXBl_12native_probe() unnamed_addr #1 {
start:
  ret i8 0
}

; <fn() as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define hidden void @_RNvYFEuINtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %_1) unnamed_addr #1 {
start:
  %_2 = alloca [0 x i8], align 1
  call void %_1()
  ret void
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once
; Function Attrs: inlinehint nonlazybind uwtable
define hidden i32 @_RNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCsgoJZQLhOXBl_12native_probe(ptr %0) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %1 = alloca [16 x i8], align 8
  %_2 = alloca [0 x i8], align 1
  %_1 = alloca [8 x i8], align 8
  store ptr %0, ptr %_1, align 8
; invoke std::rt::lang_start::<()>::{closure#0}
  %_0 = invoke i32 @_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CsgoJZQLhOXBl_12native_probe(ptr align 8 %_1)
          to label %bb1 unwind label %cleanup

bb3:                                              ; preds = %cleanup
  %2 = load ptr, ptr %1, align 8
  %3 = getelementptr inbounds i8, ptr %1, i64 8
  %4 = load i32, ptr %3, align 8
  %5 = insertvalue { ptr, i32 } poison, ptr %2, 0
  %6 = insertvalue { ptr, i32 } %5, i32 %4, 1
  resume { ptr, i32 } %6

cleanup:                                          ; preds = %start
  %7 = landingpad { ptr, i32 }
          cleanup
  %8 = extractvalue { ptr, i32 } %7, 0
  %9 = extractvalue { ptr, i32 } %7, 1
  store ptr %8, ptr %1, align 8
  %10 = getelementptr inbounds i8, ptr %1, i64 8
  store i32 %9, ptr %10, align 8
  br label %bb3

bb1:                                              ; preds = %start
  ret i32 %_0
}

; <native_probe::Generated as core::clone::Clone>::clone_from
; Function Attrs: inlinehint nonlazybind uwtable
define hidden void @_RNvYNtCsgoJZQLhOXBl_12native_probe9GeneratedNtNtCs4NRVxsYgnAr_4core5clone5Clone10clone_fromB4_(ptr %self, ptr %source) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = alloca [16 x i8], align 8
; call <native_probe::Generated as core::clone::Clone>::clone
  %_3 = call i8 @_RNvXCsgoJZQLhOXBl_12native_probeNtB2_9GeneratedNtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneB2_(ptr %source)
  br label %bb2

bb2:                                              ; preds = %start
  store i8 %_3, ptr %self, align 1
  ret void

bb3:                                              ; No predecessors!
  store i8 %_3, ptr %self, align 1
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %0, i64 8
  %3 = load i32, ptr %2, align 8
  %4 = insertvalue { ptr, i32 } poison, ptr %1, 0
  %5 = insertvalue { ptr, i32 } %4, i32 %3, 1
  resume { ptr, i32 } %5
}

; std::rt::lang_start_internal
; Function Attrs: nonlazybind uwtable
declare i64 @_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal(ptr, ptr align 8, i64, ptr, i8) unnamed_addr #0

; Function Attrs: nounwind
declare void @llvm.instrprof.increment(ptr, i64, i32, i32) #3

; Function Attrs: nounwind nonlazybind uwtable
declare i32 @rust_eh_personality(i32, i32, i64, ptr, ptr) unnamed_addr #4

; Function Attrs: nonlazybind
define i32 @main(i32 %0, ptr %1) unnamed_addr #5 {
top:
  %2 = sext i32 %0 to i64
; call std::rt::lang_start::<()>
  %3 = call i64 @_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECsgoJZQLhOXBl_12native_probe(ptr @_RNvCsgoJZQLhOXBl_12native_probe4main, i64 %2, ptr %1, i8 0)
  %4 = trunc i64 %3 to i32
  ret i32 %4
}

attributes #0 = { nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { inlinehint nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { noinline nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #3 = { nounwind }
attributes #4 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #5 = { nonlazybind "target-cpu"="x86-64" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 2, !"RtLibUseGOT", i32 1}
!3 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!4 = !{i64 4461835366423009}
